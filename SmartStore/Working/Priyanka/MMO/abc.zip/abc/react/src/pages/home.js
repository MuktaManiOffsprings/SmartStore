const Home = () =>{
    return(
        <div className = 'home'>
        This is home page
        </div>
    )
}

export default Home
