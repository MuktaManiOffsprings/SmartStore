const Signup = () =>{
    return(
        <div className = 'sign-up'>
          <input type="text" placeholder="Username" />
          <input type="text" placeholder="Password" />
          <button className="submit">Sign Up</button>
        </div>
    )
}

export default Signup
